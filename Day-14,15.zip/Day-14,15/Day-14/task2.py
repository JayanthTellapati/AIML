# Exercise 2: Implement Random Search on a Regression Model Using PyTorch
# Dataset: Boston Housing Dataset
#
# Objective: Implement random search to tune hyperparameters of a regression model using the Boston Housing dataset. Evaluate the model using various regression metrics (MAE, MSE, RMSE, R-squared).
#
# Steps:
# Load the Boston Housing dataset:
# Use sklearn.datasets.load_boston to load the dataset.
#
# Preprocess the data:
# Normalize the features using StandardScaler.
#
# Define the model and hyperparameters:
# Create a simple linear regression model using PyTorch.
# Define a range of hyperparameters to search (e.g., learning rate, number of epochs).
#
# Implement random search:
# Use sklearn.model_selection.RandomizedSearchCV to perform random search.
# Evaluate the model using cross-validation metrics.
#
# Report the best hyperparameters and model performance:
# Calculate and interpret regression metrics (MAE, MSE, RMSE, R-squared) for the best model.

import torch
import torch.nn as nn
import numpy as np
from sklearn.datasets import fetch_openml
from sklearn.model_selection import RandomizedSearchCV, KFold
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from scipy.stats import uniform
from sklearn.base import BaseEstimator, RegressorMixin

# Fetching the Boston Housing dataset using fetch_openml
boston = fetch_openml(name='boston', version=1)

# Extract features and target
X, y = boston.data, boston.target

# Preprocess the data
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Convert to PyTorch tensors
X_tensor = torch.tensor(X_scaled, dtype=torch.float32)
y_tensor = torch.tensor(y, dtype=torch.float32).view(-1, 1)

# Ensure both tensors are on the same device (cpu)
device = torch.device('cpu')
X_tensor = X_tensor.to(device)
y_tensor = y_tensor.to(device)


# Define the model
class LinearRegressionModel(nn.Module):
    def __init__(self):
        super(LinearRegressionModel, self).__init__()
        self.linear = nn.Linear(X_scaled.shape[1], 1)

    def forward(self, x):
        return self.linear(x)


# Define a range of hyperparameters to search
param_dist = {
    'lr': uniform(0.0001, 0.01),
    'num_epochs': [100, 200, 300, 400, 500]
}


# Custom PyTorch regressor class
class PyTorchRegressor(BaseEstimator, RegressorMixin):
    def __init__(self, lr=0.01, num_epochs=100):
        self.lr = lr
        self.num_epochs = num_epochs
        self.model = LinearRegressionModel()
        self.criterion = nn.MSELoss()
        self.optimizer = torch.optim.SGD(self.model.parameters(), lr=self.lr)

    def fit(self, X, y):
        for epoch in range(self.num_epochs):
            self.model.train()
            self.optimizer.zero_grad()
            outputs = self.model(X)
            loss = self.criterion(outputs, y)
            loss.backward()
            self.optimizer.step()
        return self

    def predict(self, X):
        self.model.eval()
        with torch.no_grad():
            predictions = self.model(X).numpy()
        return predictions

    def score(self, X, y):
        y_pred = self.predict(X)
        return r2_score(y.cpu().numpy(), y_pred)


# Perform random search
random_search = RandomizedSearchCV(PyTorchRegressor(), param_distributions=param_dist, n_iter=10, cv=KFold(n_splits=5),
                                   scoring='r2')
random_search.fit(X_tensor, y_tensor)

# Report the best hyperparameters and model performance
best_model = random_search.best_estimator_
best_params = random_search.best_params_
print(f'Best parameters: {best_params}')

# Evaluate the best model
y_pred = best_model.predict(X_tensor)
mae = mean_absolute_error(y_tensor.cpu().numpy(), y_pred)
mse = mean_squared_error(y_tensor.cpu().numpy(), y_pred)
rmse = np.sqrt(mse)
r2 = r2_score(y_tensor.cpu().numpy(), y_pred)

print(f'Best Model - MAE: {mae:.4f}, MSE: {mse:.4f}, RMSE: {rmse:.4f}, R-squared: {r2:.4f}')
