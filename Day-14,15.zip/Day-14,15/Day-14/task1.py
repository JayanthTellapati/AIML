
# Exercise 1: Implement Grid Search on a Regression Model Using PyTorch
# Dataset: California Housing Dataset
#
# Objective: Implement grid search to tune hyperparameters of a regression model using the California Housing dataset. Evaluate the model using various regression metrics (MAE, MSE, RMSE, R-squared).
#
# Steps:
# Load the California Housing dataset:
# Use sklearn.datasets.fetch_california_housing to load the dataset.
#
# Preprocess the data:
# Normalize the features using StandardScaler.
#
# Define the model and hyperparameters:
# Create a simple linear regression model using PyTorch.
# Define a grid of hyperparameters to search (e.g., learning rate, number of epochs).
#
# Implement grid search:
# Use sklearn.model_selection.GridSearchCV to perform grid search.
# Evaluate the model using cross-validation metrics.
#
# Report the best hyperparameters and model performance:
# Calculate and interpret regression metrics (MAE, MSE, RMSE, R-squared) for the best model.

import torch
import torch.nn as nn
import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import fetch_california_housing
from sklearn.model_selection import GridSearchCV, KFold
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import make_scorer, mean_absolute_error, mean_squared_error, r2_score

# Load the California Housing dataset
data = fetch_california_housing()
X, y = data.data, data.target

# Preprocess the data
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Convert to PyTorch tensors
X_tensor = torch.tensor(X_scaled, dtype=torch.float32)
y_tensor = torch.tensor(y, dtype=torch.float32).view(-1, 1)


# Define the model
class LinearRegressionModel(nn.Module):
    def __init__(self):
        super(LinearRegressionModel, self).__init__()
        self.linear = nn.Linear(X.shape[1], 1)

    def forward(self, x):
        return self.linear(x)


# Define a grid of hyperparameters to search
param_grid = {
    'lr': [0.01, 0.001, 0.0001],
    'num_epochs': [100, 200, 300]
}


# Custom class to use with GridSearchCV
class PyTorchRegressor:
    def __init__(self, lr=0.01, num_epochs=100):
        self.lr = lr
        self.num_epochs = num_epochs
        self.model = LinearRegressionModel()
        self.criterion = nn.MSELoss()

    def fit(self, X, y):
        optimizer = torch.optim.SGD(self.model.parameters(), lr=self.lr)

        for epoch in range(self.num_epochs):
            self.model.train()
            optimizer.zero_grad()
            outputs = self.model(X)
            loss = self.criterion(outputs, y)
            loss.backward()
            optimizer.step()

    def predict(self, X):
        self.model.eval()
        with torch.no_grad():
            predictions = self.model(X).numpy()
        return predictions

    def score(self, X, y):
        y_pred = self.predict(X)
        return r2_score(y.numpy(), y_pred)


# Implement grid search manually
best_score = float('-inf')
best_params = None

for lr in param_grid['lr']:
    for num_epochs in param_grid['num_epochs']:
        kf = KFold(n_splits=5)
        scores = []

        for train_index, val_index in kf.split(X_tensor):
            X_train, X_val = X_tensor[train_index], X_tensor[val_index]
            y_train, y_val = y_tensor[train_index], y_tensor[val_index]

            model = LinearRegressionModel()
            criterion = nn.MSELoss()
            optimizer = torch.optim.SGD(model.parameters(), lr=lr)

            for epoch in range(num_epochs):
                model.train()
                optimizer.zero_grad()
                outputs = model(X_train)
                loss = criterion(outputs, y_train)
                loss.backward()
                optimizer.step()

            model.eval()
            with torch.no_grad():
                y_pred = model(X_val)
                score = r2_score(y_val.numpy(), y_pred.numpy())
                scores.append(score)

        avg_score = np.mean(scores)
        if avg_score > best_score:
            best_score = avg_score
            best_params = {'lr': lr, 'num_epochs': num_epochs}

# Report the best hyperparameters
print(f'Best parameters: {best_params}')
print(f'Best R-squared score from cross-validation: {best_score:.4f}')

# Train the best model on the full dataset
best_model = LinearRegressionModel()
best_criterion = nn.MSELoss()
best_optimizer = torch.optim.SGD(best_model.parameters(), lr=best_params['lr'])

for epoch in range(best_params['num_epochs']):
    best_model.train()
    best_optimizer.zero_grad()
    outputs = best_model(X_tensor)
    loss = best_criterion(outputs, y_tensor)
    loss.backward()
    best_optimizer.step()

# Evaluate the best model
best_model.eval()
with torch.no_grad():
    y_pred = best_model(X_tensor).numpy()

mae = mean_absolute_error(y_tensor.numpy(), y_pred)
mse = mean_squared_error(y_tensor.numpy(), y_pred)
rmse = np.sqrt(mse)
r2 = r2_score(y_tensor.numpy(), y_pred)

print(f'Best Model - MAE: {mae:.4f}, MSE: {mse:.4f}, RMSE: {rmse:.4f}, R-squared: {r2:.4f}')
