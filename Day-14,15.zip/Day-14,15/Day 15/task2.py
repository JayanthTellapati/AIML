# Assignment 2: Implement a Gradient Boosting Regressor Using PyTorch
# Dataset: Any Housing Dataset
#
# Objective: Implement a Gradient Boosting regressor to predict housing prices using the  Housing dataset. Evaluate the model using various regression metrics (MAE, MSE, RMSE, R-squared).
#
# Steps:
# Load the Housing dataset:
#
# Preprocess the data:
# Normalize the features using StandardScaler.
#
# Define the model:
# Create a simple linear regression model using PyTorch.
#
# Implement Gradient Boosting:
# Use sklearn.ensemble.GradientBoostingRegressor to implement the Gradient Boosting ensemble method.
# Train the model on the training data.
#
# Evaluate the model:
# Calculate and interpret regression metrics (MAE, MSE, RMSE, R-squared) on the test set.


import pandas as pd
from sklearn.datasets import fetch_california_housing
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import numpy as np

# Step 1: Load the Housing dataset
housing_data = fetch_california_housing()

# Step 2: Preprocess the data
X = housing_data.data
y= housing_data.target

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Split data into train and test sets
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# Step 3: Implement Gradient Boosting using GradientBoostingRegressor
gb_regressor = GradientBoostingRegressor(random_state=42)

# Train the model on the training data
gb_regressor.fit(X_train, y_train)

# Predict on the test set
y_pred = gb_regressor.predict(X_test)

# Step 4: Evaluate the model
mae = mean_absolute_error(y_test, y_pred)
mse = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)
r2 = r2_score(y_test, y_pred)

print(f"Mean Absolute Error (MAE): {mae:.4f}")
print(f"Mean Squared Error (MSE): {mse:.4f}")
print(f"Root Mean Squared Error (RMSE): {rmse:.4f}")
print(f"R-squared (R2): {r2:.4f}")
