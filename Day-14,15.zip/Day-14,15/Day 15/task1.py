# DAY 15
#
#
# Assignment 1: Implement a Bagging Regressor Using PyTorch
# Dataset: Diabetes Dataset
#
# Objective: Implement a Bagging regressor to predict diabetes progression using the Diabetes dataset. Evaluate the model using various regression metrics (MAE, MSE, RMSE, R-squared).
#
# Steps:
#
# Load the Diabetes dataset:
# Use sklearn.datasets.load_diabetes to load the dataset.
#
# Preprocess the data:
# Normalize the features using StandardScaler.
#
# Define the model:
# Create a simple linear regression model using PyTorch.
#
# Implement Bagging:
# Use sklearn.ensemble.BaggingRegressor to implement the Bagging ensemble method.
# Train multiple models on different subsets of the training data.
#
# Evaluate the model:
# Calculate and interpret regression metrics (MAE, MSE, RMSE, R-squared) on the test set.


from sklearn.datasets import load_diabetes
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import BaggingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import torch
import torch.nn as nn
import numpy as np

# Step 1: Load the Diabetes dataset
data = load_diabetes()
X, y = data.data, data.target

# Step 2: Preprocess the data
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Split data into train and test sets
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# Convert data to PyTorch tensors
X_train_tensor = torch.from_numpy(X_train).float()
y_train_tensor = torch.from_numpy(y_train).float().view(-1, 1)
X_test_tensor = torch.from_numpy(X_test).float()
y_test_tensor = torch.from_numpy(y_test).float().view(-1, 1)

# Step 3: Define the base model in PyTorch
class LinearRegressionModel(nn.Module):
    def __init__(self, input_size, output_size):
        super(LinearRegressionModel, self).__init__()
        self.linear = nn.Linear(input_size, output_size)

    def forward(self, x):
        return self.linear(x)

# Step 4: Implement Bagging using BaggingRegressor
base_model = LinearRegressionModel(X_train.shape[1], 1)
bagging_model = BaggingRegressor(n_estimators=10, random_state=42)

# Fit the Bagging model
bagging_model.fit(X_train, y_train)

# Predict on the test set
y_pred = bagging_model.predict(X_test)

# Step 5: Evaluate the model
mae = mean_absolute_error(y_test, y_pred)
mse = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)
r2 = r2_score(y_test, y_pred)

print(f"Mean Absolute Error (MAE): {mae:.4f}")
print(f"Mean Squared Error (MSE): {mse:.4f}")
print(f"Root Mean Squared Error (RMSE): {rmse:.4f}")
print(f"R-squared (R2): {r2:.4f}")



