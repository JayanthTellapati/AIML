# Assignment 2: Performing Polynomial Regression and Feature Engineering
#
# Problem 1: Load a dataset and perform polynomial regression. Add polynomial features up to degree 3 and train the model using these features.
# Problem 2: Compare the performance of the polynomial regression model with the linear regression model using MSE.

import torch
import torch.nn as nn
import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import PolynomialFeatures
from sklearn.metrics import mean_squared_error

# Load the dataset
diabetes = load_diabetes()
X = diabetes.data[:, np.newaxis, 2]  # Use only one feature for simplicity
y = diabetes.target.reshape(-1, 1)

# Split the dataset into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Feature Engineering (Creating Polynomial Features)

# Create polynomial features up to degree 3
poly = PolynomialFeatures(degree=3)
X_train_poly = poly.fit_transform(X_train)
X_test_poly = poly.transform(X_test)

# Convert polynomial features to PyTorch tensors
X_train_tensor = torch.from_numpy(X_train_poly).float()
X_test_tensor = torch.from_numpy(X_test_poly).float()
y_train_tensor = torch.from_numpy(y_train).float()
y_test_tensor = torch.from_numpy(y_test).float()

# Define and Train the Model

class PolynomialRegressionModel(nn.Module):
    def __init__(self):
        super(PolynomialRegressionModel, self).__init__()
        self.linear = nn.Linear(X_train_poly.shape[1], 1)

    def forward(self, x):
        return self.linear(x)

model = PolynomialRegressionModel()

# Define the loss function and the optimizer
criterion = nn.MSELoss()
optimizer = torch.optim.SGD(model.parameters(), lr=0.01)

# Training loop
num_epochs = 1000
for epoch in range(num_epochs):
    model.train()
    optimizer.zero_grad()

    # Forward pass
    outputs = model(X_train_tensor)
    loss = criterion(outputs, y_train_tensor)

    # Backward pass and optimization
    loss.backward()
    optimizer.step()

    if (epoch+1) % 100 == 0:
        print(f'Epoch [{epoch+1}/{num_epochs}], Loss: {loss.item():.4f}')

# Evaluating the Model

model.eval()
with torch.no_grad():
    predicted_train = model(X_train_tensor).numpy()
    predicted_test = model(X_test_tensor).numpy()

# Calculate Mean Squared Error for both training and test sets
train_mse = mean_squared_error(y_train, predicted_train)
test_mse = mean_squared_error(y_test, predicted_test)
print(f'Training MSE: {train_mse:.4f}')
print(f'Test MSE: {test_mse:.4f}')
