# Assignment 3: Applying Ridge and Lasso Regression
#
# Problem 1: Implement Ridge regression on the same dataset used in Assignment 1. Use cross-validation to select the best regularization parameter (alpha).
# Problem 2: Implement Lasso regression on the same dataset. Use cross-validation to select the best regularization parameter (alpha).
# Problem 3: Compare the performance of Ridge, Lasso, and standard linear regression models in terms of MSE and interpret the results.

import numpy as np
import torch
import torch.nn as nn
from sklearn.datasets import fetch_california_housing
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.linear_model import Ridge, Lasso
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import StandardScaler

# Load the California Housing dataset
california_housing = fetch_california_housing()
X = california_housing.data
y = california_housing.target

# Standardize the input features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Split the dataset into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# Ridge Regression
print('Ridge Regression')
ridge = Ridge()
parameters = {'alpha': [0.01, 0.1, 1, 10, 100]}
ridge_regressor = GridSearchCV(ridge, parameters, scoring='neg_mean_squared_error', cv=5)
ridge_regressor.fit(X_train, y_train)
best_alpha_ridge = ridge_regressor.best_params_['alpha']
print('Best alpha for Ridge:', best_alpha_ridge)

# Train Ridge regression model with best alpha
ridge_model = Ridge(alpha=best_alpha_ridge)
ridge_model.fit(X_train, y_train)

# Predictions
y_pred_ridge_train = ridge_model.predict(X_train)
y_pred_ridge_test = ridge_model.predict(X_test)

# MSE for Ridge regression
mse_ridge_train = mean_squared_error(y_train, y_pred_ridge_train)
mse_ridge_test = mean_squared_error(y_test, y_pred_ridge_test)
print('Ridge Regression - Training MSE:', mse_ridge_train)
print('Ridge Regression - Test MSE:', mse_ridge_test)

# Lasso Regression
print('Lasso Regression')
lasso = Lasso()
parameters = {'alpha': [0.01, 0.1, 1, 10, 100]}
lasso_regressor = GridSearchCV(lasso, parameters, scoring='neg_mean_squared_error', cv=5)
lasso_regressor.fit(X_train, y_train)
best_alpha_lasso = lasso_regressor.best_params_['alpha']
print('Best alpha for Lasso:', best_alpha_lasso)

# Train Lasso regression model with best alpha
lasso_model = Lasso(alpha=best_alpha_lasso)
lasso_model.fit(X_train, y_train)

# Predictions
y_pred_lasso_train = lasso_model.predict(X_train)
y_pred_lasso_test = lasso_model.predict(X_test)

# MSE for Lasso regression
mse_lasso_train = mean_squared_error(y_train, y_pred_lasso_train)
mse_lasso_test = mean_squared_error(y_test, y_pred_lasso_test)
print('Lasso Regression - Training MSE:', mse_lasso_train)
print('Lasso Regression - Test MSE:', mse_lasso_test)

# Standard Linear Regression
print('Standard Linear Regression')
linear_model = nn.Linear(X_train.shape[1], 1)
criterion = nn.MSELoss()
optimizer = torch.optim.SGD(linear_model.parameters(), lr=0.01)

# Convert to PyTorch tensors
X_train_tensor = torch.from_numpy(X_train).float()
X_test_tensor = torch.from_numpy(X_test).float()
y_train_tensor = torch.from_numpy(y_train).float().view(-1, 1)
y_test_tensor = torch.from_numpy(y_test).float().view(-1, 1)

# Training loop
num_epochs = 1000
for epoch in range(num_epochs):
    linear_model.train()
    optimizer.zero_grad()

    # Forward pass
    outputs = linear_model(X_train_tensor)
    loss = criterion(outputs, y_train_tensor)

    # Backward pass and optimization
    loss.backward()
    optimizer.step()

    if (epoch + 1) % 100 == 0:
        print(f'Epoch [{epoch + 1}/{num_epochs}], Loss: {loss.item():.4f}')

# Predictions
with torch.no_grad():
    y_pred_linear_train = linear_model(X_train_tensor).numpy()
    y_pred_linear_test = linear_model(X_test_tensor).numpy()

# MSE for linear regression
mse_linear_train = mean_squared_error(y_train, y_pred_linear_train)
mse_linear_test = mean_squared_error(y_test, y_pred_linear_test)
print('Standard Linear Regression - Training MSE:', mse_linear_train)
print('Standard Linear Regression - Test MSE:', mse_linear_test)
