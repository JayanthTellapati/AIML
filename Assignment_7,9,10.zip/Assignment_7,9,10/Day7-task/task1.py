# Assignment 2: Applying Transformations using torchvision.transforms
#
# Problem 1: Load an image using PIL, convert it to a PyTorch tensor, and normalize it using torchvision.transforms.Normalize with mean=0.5 and std=0.5.
#
# Problem 2: Create a custom transformation that rotates an image by 45 degrees and apply it to an image. Use torchvision.transforms.Compose to chain this custom transformation with a resize transformation that resizes the image to 128x128 pixels.
#
# Problem 3: Use torchvision.transforms to apply the following transformations to an image:
#
# Random horizontal flip.
# Random crop of size 100x100.
# Convert the image to grayscale.


from torchvision import transforms
from PIL import Image

# Load an image using PIL
image = Image.open("cat.jpg")

# Convert it to a PyTorch tensor and normalize it using torchvision.transforms.Normalize with mean=0.5 and std=0.5
to_tensor = transforms.ToTensor()
normalize = transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
transform1 = transforms.Compose([to_tensor, normalize])
normalized_image = transform1(image)

# Convert the normalized tensor back to a PIL image
normalized_image_pil = transforms.ToPILImage()(normalized_image)

print("Problem 1:")
# Save the normalized image
normalized_image_pil.save('normalized_image.png')
print("Normalized Image saved successfully.")


# Rotate the image by 45 degrees and resize it to 128x128 pixels
rotate_transform = transforms.Compose([
    transforms.RandomRotation(45),
    transforms.Resize((128, 128))
])
transformed_image1 = rotate_transform(image)

print("\nProblem 2:")
print("Transformed Image:")
# Save the transformed image
transformed_image1.save('transformed_image.png')

# Apply random horizontal flip, random crop of size 100x100, and convert the image to grayscale
random_transform = transforms.Compose([
    transforms.RandomHorizontalFlip(),
    transforms.RandomCrop((100, 100)),
    transforms.Grayscale()
])
transformed_image2 = random_transform(image)

print("\nProblem 3:")
print("Transformed Image with Random Horizontal Flip, Random Crop, and Grayscale:")
# Save the transformed image
transformed_image2.save('transformed_image_extras.png')


