# Assignment 1: Creating and Manipulating PyTorch Tensors
#
# Problem 1: Create a 3x3 tensor with random values and perform the following operations:
#
# Add 10 to each element.
# Multiply each element by 2.
# Calculate the mean and standard deviation of the tensor.
#
# Problem 2: Create two tensors of size 3x3 with random values and perform element-wise addition and multiplication.
#
# Problem 3: Create a tensor with values from 1 to 16 and reshape it to a 4x4 tensor. Extract the first two rows and last two columns.



import torch

# Problem 1
tensor1 = torch.randn(3, 3)
tensor1_add = tensor1 + 10
tensor1_mul = tensor1 * 2
mean = tensor1.mean()
std = tensor1.std()

print("Problem 1:")
print("Original Tensor:")
print(tensor1)
print("\nTensor after adding 10 to each element:")
print(tensor1_add)
print("\nTensor after multiplying each element by 2:")
print(tensor1_mul)
print("\nMean of the tensor:", mean)
print("Standard deviation of the tensor:", std)

# Problem 2
tensor2_1 = torch.randn(3, 3)
tensor2_2 = torch.randn(3, 3)
tensor2_add = tensor2_1 + tensor2_2
tensor2_mul = tensor2_1 * tensor2_2

print("\nProblem 2:")
print("Tensor 1:")
print(tensor2_1)
print("\nTensor 2:")
print(tensor2_2)
print("\nElement-wise addition:")
print(tensor2_add)
print("\nElement-wise multiplication:")
print(tensor2_mul)

# Problem 3
tensor3 = torch.arange(1, 17)
tensor3_reshape = tensor3.reshape(4, 4)
extracted_tensor = tensor3_reshape[:2, -2:]

print("\nProblem 3:")
print("Original Tensor:")
print(tensor3_reshape)
print("\nExtracted Tensor (First two rows and last two columns):")
print(extracted_tensor)
