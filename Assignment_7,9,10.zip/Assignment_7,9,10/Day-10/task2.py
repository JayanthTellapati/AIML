# Question 2
# Implement the k-Nearest Neighbors (k-NN) algorithm to classify the Wine Quality dataset into good and bad quality wines using different values of k. Evaluate the model's performance using accuracy.
#
# Steps:
#
# Load the Wine Quality dataset from the UCI Machine Learning Repository.
# Preprocess the data: normalize the features and binarize the target variable into good (quality >= 7) and bad (quality < 7).
# Split the data into training and testing sets.
# Implement the k-NN algorithm
# Experiment with different values of k (e.g., k=3, 5, 7) and evaluate the model's performance.
# Report the accuracy for each value of k

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

# Step 1: Load the Wine Quality dataset
url = "https://archive.ics.uci.edu/ml/machine-learning-databases/wine-quality/winequality-red.csv"
data = pd.read_csv(url, sep=';')

# Step 2: Preprocess the data
# Binarize the target variable into good (quality >= 7) and bad (quality < 7)
data['quality'] = np.where(data['quality'] >= 7, 1, 0)

# Normalize the features
X = data.drop('quality', axis=1)
scaler = StandardScaler()
X = scaler.fit_transform(X)

y = data['quality']

# Step 3: Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 4: Implement the k-NN algorithm
def knn_classifier(k):
    knn = KNeighborsClassifier(n_neighbors=k)
    knn.fit(X_train, y_train)
    y_pred = knn.predict(X_test)
    return y_pred

# Step 5: Experiment with different values of k and evaluate the model's performance
k_values = [3, 5, 7]
for k in k_values:
    y_pred = knn_classifier(k)
    accuracy = accuracy_score(y_test, y_pred)
    print(f"Accuracy for k={k}: {accuracy}")

# Step 6: Report the accuracy for each value of k
