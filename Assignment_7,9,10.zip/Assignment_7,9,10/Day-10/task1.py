# Question 1
# Implement logistic regression to classify the Balance scale dataset into two classes using only 'L', and 'R' using PyTorch. Evaluate the model's performance using accuracy.
#
# Steps:
#
# Load the Balance scale dataset.
# Preprocess the data: normalize the features and drop the 'B' value in target.
# Split the data into training and testing sets.
# Implement the logistic regression model using PyTorch.
# Train the model and evaluate its performance on the test set.
# Report the accuracy of the model.

import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.model_selection import train_test_split

# Load the dataset
data = pd.read_csv("balance_scale_data.csv")

# Preprocess the data
data = data[data['Class'] != 'B']  # Remove 'B' class
data['Class'] = data['Class'].map({'L': 0, 'R': 1})  # Convert 'L' and 'R' to 0 and 1
X = data.iloc[:, 1:].values.astype(float)  # Features
y = data['Class'].values  # Target

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Convert to PyTorch tensors
X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
X_test_tensor = torch.tensor(X_test, dtype=torch.float32)
y_train_tensor = torch.tensor(y_train, dtype=torch.float32)
y_test_tensor = torch.tensor(y_test, dtype=torch.float32)

# Define logistic regression model
class LogisticRegression(nn.Module):
    def __init__(self, input_dim):
        super(LogisticRegression, self).__init__()
        self.linear = nn.Linear(input_dim, 1)

    def forward(self, x):
        out = torch.sigmoid(self.linear(x))
        return out

input_dim = X_train.shape[1]
model = LogisticRegression(input_dim)

# Define loss function and optimizer
criterion = nn.BCELoss()
optimizer = optim.SGD(model.parameters(), lr=0.1)

# Training the model
num_epochs = 1000
for epoch in range(num_epochs):
    optimizer.zero_grad()
    outputs = model(X_train_tensor)
    loss = criterion(outputs, y_train_tensor.view(-1, 1))
    loss.backward()
    optimizer.step()
    if (epoch+1) % 100 == 0:
        print(f'Epoch [{epoch+1}/{num_epochs}], Loss: {loss.item():.4f}')

# Evaluation
with torch.no_grad():
    outputs = model(X_test_tensor)
    predicted = (outputs >= 0.5).float()
    accuracy = (predicted == y_test_tensor.view(-1, 1)).sum().item() / y_test_tensor.size(0)
    print(f'Accuracy: {accuracy:.4f}')
