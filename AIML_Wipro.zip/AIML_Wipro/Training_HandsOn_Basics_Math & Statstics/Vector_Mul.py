import numpy as np

scalar = 3
vector = np.array([1,2])
vector_scaled = vector * scalar

print("Sacalr Multiplication using python")
print("Scalar",scalar)
print("Original vector",vector)
print("Scaled vector",vector_scaled)