import numpy as np

vector_2D = [1, 2]
vector_3D = [1, 2, 3]

# Convert lists to NumPy arrays
vector_2D_array = np.array(vector_2D)
vector_3D_array = np.array(vector_3D)

# # Calculate magnitude (length) of the vectors
# magnitude_2D = np.linalg.norm(vector_2D_array)
# magnitude_3D = np.linalg.norm(vector_3D_array)

# print("Magnitude of 2D vector:", magnitude_2D)
# print("Magnitude of 3D vector:", magnitude_3D)
